const messages = [
  "You make my heart feel at home.",
  "Every moment with you is my favorite.",
  "Your smile feels like sunrise to my soul.",
  "You are my safe place, my peace, my sweetest feeling.",
  "Every day with you feels like magic.",
  "Loving you is the easiest thing I have ever done.",
  "Your presence is my favorite comfort.",
  "You are my happy thought, always.",
  "If my heart could speak, it would say your name first.",
  "You make ordinary moments unforgettable."
];

const messageBox = document.querySelector(".textMessage");
const genBtn = document.getElementById("gen-text");

function generateMessage() {
  const randomIndex = Math.floor(Math.random() * messages.length);
  messageBox.textContent = messages[randomIndex];
}

generateMessage();
genBtn.addEventListener("click", generateMessage);